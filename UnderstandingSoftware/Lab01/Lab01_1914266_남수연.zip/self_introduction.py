name = input("이름 : ")
major = input("전공 : ")
std_num = int(input("학번 : "))
birthday = input("생년 월일 : ")

print("[자기소개]\n숙명여대", major, std_num, "학번", name, "입니다.")
print("제 생년월일은", birthday, "입니다.")