import turtle

t = turtle.Pen()
t.shape("turtle")
t.color("green")

t.forward(100)
t.left(120)
t.forward(100)
t.left(120)
t.forward(100)
t.left(120)