sc1 = float(input("Enter score 1 : "))
sc2 = float(input("Enter score 2 : "))
sc3 = float(input("Enter score 3 : "))
sc4 = float(input("Enter score 4 : "))
sc5 = float(input("Enter score 5 : "))

sum = sc1 + sc2 + sc3 + sc4 + sc5
aver = (sum) / 5

print("[Result]")
print("Total score :", sum)
print("Average score :", aver)